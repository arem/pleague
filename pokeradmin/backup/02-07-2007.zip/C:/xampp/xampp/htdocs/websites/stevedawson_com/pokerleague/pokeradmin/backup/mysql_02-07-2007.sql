create database pokerleague;

create table pokermax_admin
(
	id int auto_increment primary key,
	username varchar(150),
	password varchar(150),
	league_name varchar(200),
	league_information text,
	league_email varchar(255),
	league_tournament_director varchar(255)
);

insert into pokermax_admin (id, username, password, league_name, league_information, league_email, league_tournament_director) values (1, "steve", "steve", "Golden Eagle Poker League", "Pub League which meets at the Golden Eagle Pub in Bispham on Tuesday nights.\r\n\r\nRegistration starts at 7.45\r\nTournament commences at 8.15\r\n\r\nAny newcomers are welcome to join the friendly atmosphere and join the poker tournaments. Maybe even win a prize or two - you never know!", "ste707@gmail.com", "Steve Dawson");


create table pokermax_players
(
	id int auto_increment primary key,
	playerid varchar(50),
	name varchar(150),
	team varchar(150),
	email varchar(150),
	profile varchar(150),
	websiteurl varchar(150),
	photo varchar(100),
	activated varchar(1),
	dateadded varchar(150)
);

insert into pokermax_players (id, playerid, name, team, email, profile, websiteurl, photo, activated, dateadded) values (1, "dawnie", "Dawn Wolstencroft", "AWOP", "ste707@gmail.com", "Poker League All Rights Reserved", "", "", "Y", "18 April 2007");
insert into pokermax_players (id, playerid, name, team, email, profile, websiteurl, photo, activated, dateadded) values (2, "Ste", "Steve Dawson", "PokerLOG", "ste707@gmail.com", "just another poker player", "", "", "Y", "18 April 2007");
insert into pokermax_players (id, playerid, name, team, email, profile, websiteurl, photo, activated, dateadded) values (6, "RyanD", "Ryan Dawson", "", "ryantedford1989@hotmail.co.uk", "", "", "", "Y", "30 June 2007");
insert into pokermax_players (id, playerid, name, team, email, profile, websiteurl, photo, activated, dateadded) values (7, "BettyBoo", "Bethany Dawson", "AWOP", "", "A little girl who likes to play poker", "", "", "Y", "1 July 2007");


create table pokermax_scores
(
	id int auto_increment primary key,
	playerid varchar(50),
	tournamentid varchar(50),
	points int,
	dateadded varchar(150)
);

insert into pokermax_scores (id, playerid, tournamentid, points, dateadded) values (1, "Ste", "180407093106", 20, "19 April 2007");
insert into pokermax_scores (id, playerid, tournamentid, points, dateadded) values (2, "dawnie", "180407095313", 42, "19 April 2007");
insert into pokermax_scores (id, playerid, tournamentid, points, dateadded) values (3, "dawnie", "180407093106", 6, "19 April 2007");
insert into pokermax_scores (id, playerid, tournamentid, points, dateadded) values (4, "Ste", "180407095313", 9, "30 June 2007");
insert into pokermax_scores (id, playerid, tournamentid, points, dateadded) values (5, "RyanD", "180407093106", 10, "30 June 2007");
insert into pokermax_scores (id, playerid, tournamentid, points, dateadded) values (6, "BettyBoo", "180407095313", 58, "1 July 2007");
insert into pokermax_scores (id, playerid, tournamentid, points, dateadded) values (8, "BettyBoo", "010707143538", 6, "1 July 2007");


create table pokermax_tournaments
(
	id int auto_increment primary key,
	tournamentid varchar(50),
	tournament_name varchar(255),
	tournament_venue varchar(200),
	tournament_date varchar(100),
	dateadded varchar(150)
);

insert into pokermax_tournaments (id, tournamentid, tournament_name, tournament_venue, tournament_date, dateadded) values (1, "180407093106", "Golden Eagle Poker League Round One", "Golden Eagle Bispham Lancashire", "22nd April 2007", "18 April 2007");
insert into pokermax_tournaments (id, tournamentid, tournament_name, tournament_venue, tournament_date, dateadded) values (2, "180407095313", "Golden Eagle Poker League Round Two", "Golden Eagle", "29nd April 2007", "18 April 2007");
insert into pokermax_tournaments (id, tournamentid, tournament_name, tournament_venue, tournament_date, dateadded) values (3, "010707143538", "Golden Eagle Poker League Round Three", "Golden Eagle ", "1st July 2007", "1 July 2007");
insert into pokermax_tournaments (id, tournamentid, tournament_name, tournament_venue, tournament_date, dateadded) values (4, "010707222924", "Golden Eagle Poker League Round Four", "Black Bull", "1st July 2007", "1 July 2007");


